import type { Metadata, Viewport } from 'next'
import { Geist } from 'next/font/google'
import { Analytics } from '@vercel/analytics/next'
import './globals.css'

const geist = Geist({ 
  subsets: ["latin"],
  variable: '--font-geist'
})

export const metadata: Metadata = {
  title: 'Happy Yemen Restaurant | مطعم اليمن السعيد - Authentic Yemeni Cuisine in Abu Dhabi',
  description: 'Experience authentic Yemeni flavors at Happy Yemen Restaurant in Abu Dhabi. Famous for Mandi, Madfoon, Fahsa and traditional Yemeni dishes. Dine-in, delivery & takeaway available.',
  keywords: ['Yemeni restaurant', 'Abu Dhabi', 'Mandi', 'Madfoon', 'Fahsa', 'Arabic food', 'Middle Eastern cuisine', 'مطعم اليمن السعيد'],
  authors: [{ name: 'Happy Yemen Restaurant' }],
  creator: 'Happy Yemen Restaurant',
  openGraph: {
    title: 'Happy Yemen Restaurant | مطعم اليمن السعيد',
    description: 'Authentic Yemeni Flavors in the Heart of Abu Dhabi',
    type: 'website',
    locale: 'en_AE',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Happy Yemen Restaurant | مطعم اليمن السعيد',
    description: 'Authentic Yemeni Flavors in the Heart of Abu Dhabi',
  },
  robots: {
    index: true,
    follow: true,
  },
}

export const viewport: Viewport = {
  themeColor: '#5c4033',
  width: 'device-width',
  initialScale: 1,
  maximumScale: 5,
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" dir="ltr">
      <head>
        <link
          href="https://fonts.googleapis.com/css2?family=Noto+Sans+Arabic:wght@400;500;600;700&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className={`${geist.variable} font-sans antialiased`}>
        {children}
        <Analytics />
      </body>
    </html>
  )
}
