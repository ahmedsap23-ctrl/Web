'use client'

import { useRef } from 'react'
import { motion, useInView } from 'framer-motion'
import { MapPin, Phone, Clock, Navigation } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'

const contactInfo = [
  {
    icon: MapPin,
    title: 'Address',
    details: ['1220 Sultan Bin Zayed The First St', 'Hadbat Al Za\'faranah - Zone 1', 'Abu Dhabi, UAE'],
    action: 'Get Directions',
    href: 'https://www.google.com/maps/search/?api=1&query=Happy+Yemen+Restaurant+Abu+Dhabi'
  },
  {
    icon: Phone,
    title: 'Phone',
    details: ['+971 2 445 2412'],
    action: 'Call Now',
    href: 'tel:+97124452412'
  },
  {
    icon: Clock,
    title: 'Opening Hours',
    details: ['Daily: 3:00 PM - 3:00 AM', 'Open 7 days a week'],
    action: null,
    href: null
  }
]

export function LocationSection() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: '-100px' })

  return (
    <section id="location" className="py-20 md:py-32 bg-secondary">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <div className="flex items-center justify-center gap-2 mb-4">
            <div className="h-px w-12 bg-accent" />
            <span className="text-accent font-medium uppercase tracking-wider text-sm">
              Find Us
            </span>
            <div className="h-px w-12 bg-accent" />
          </div>
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-foreground mb-4">
            Visit Our <span className="text-accent">Restaurant</span>
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Located in the heart of Abu Dhabi, we are ready to serve you 
            authentic Yemeni cuisine.
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-8 items-start">
          {/* Contact Cards */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="grid gap-4"
          >
            {contactInfo.map((info, index) => (
              <Card key={info.title} className="border-border/50">
                <CardContent className="p-6">
                  <div className="flex gap-4">
                    <div className="flex-shrink-0 w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                      <info.icon className="w-6 h-6 text-primary" />
                    </div>
                    <div className="flex-grow">
                      <h3 className="font-semibold text-foreground mb-2">{info.title}</h3>
                      {info.details.map((detail, i) => (
                        <p key={i} className="text-muted-foreground text-sm">
                          {detail}
                        </p>
                      ))}
                      {info.action && info.href && (
                        <a href={info.href} target="_blank" rel="noopener noreferrer" className="mt-3 inline-block">
                          <Button variant="outline" size="sm" className="gap-2">
                            <Navigation className="w-4 h-4" />
                            {info.action}
                          </Button>
                        </a>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}

            {/* Quick Note */}
            <Card className="bg-accent/10 border-accent/20">
              <CardContent className="p-6">
                <p className="text-sm text-foreground">
                  <strong className="text-accent">Note:</strong> We are open until 3:00 AM for late-night 
                  cravings. Reopening daily at 3:00 PM. Private dining and catering services available 
                  upon request.
                </p>
              </CardContent>
            </Card>
          </motion.div>

          {/* Google Map */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="relative"
          >
            <div className="aspect-[4/3] lg:aspect-square rounded-2xl overflow-hidden shadow-xl">
              <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3631.6677611454584!2d54.37175871536576!3d24.453884784234!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3e5e655e6c7e4b65%3A0x6fa4adbcbd95a0f5!2sHappy%20Yemen%20Restaurant!5e0!3m2!1sen!2sae!4v1645678901234!5m2!1sen!2sae"
                width="100%"
                height="100%"
                style={{ border: 0 }}
                allowFullScreen
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                title="Happy Yemen Restaurant Location"
                className="grayscale hover:grayscale-0 transition-all duration-500"
              />
            </div>
            {/* Decorative elements */}
            <div className="absolute -bottom-4 -right-4 w-32 h-32 bg-accent/20 rounded-2xl -z-10" />
            <div className="absolute -top-4 -left-4 w-24 h-24 bg-primary/10 rounded-2xl -z-10" />
          </motion.div>
        </div>
      </div>
    </section>
  )
}
