'use client'

import { useRef } from 'react'
import { motion, useInView } from 'framer-motion'
import { Phone, ExternalLink, FileText, Instagram } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'

const orderOptions = [
  {
    icon: Phone,
    title: 'Call to Order',
    description: 'Speak directly with our team',
    action: 'Call +971 2 445 2412',
    href: 'tel:+97124452412',
    primary: true
  },
  {
    icon: ExternalLink,
    title: 'Order Online',
    description: 'Quick and easy online ordering',
    action: 'Order Now',
    href: '#',
    primary: true
  },
  {
    icon: FileText,
    title: 'View Full Menu',
    description: 'Browse our complete menu',
    action: 'Download Menu',
    href: '#menu',
    primary: false
  },
  {
    icon: Instagram,
    title: 'Follow Us',
    description: 'Daily specials on Instagram',
    action: 'Visit Instagram',
    href: 'https://instagram.com',
    primary: false
  }
]

export function OrderSection() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: '-100px' })

  return (
    <section id="order" className="py-20 md:py-32 bg-primary relative overflow-hidden">
      {/* Decorative Pattern */}
      <div className="absolute inset-0 opacity-5">
        <svg className="w-full h-full" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <pattern id="orderPattern" x="0" y="0" width="80" height="80" patternUnits="userSpaceOnUse">
              <circle cx="40" cy="40" r="20" fill="none" stroke="currentColor" strokeWidth="1" className="text-white" />
              <circle cx="40" cy="40" r="10" fill="none" stroke="currentColor" strokeWidth="1" className="text-white" />
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#orderPattern)" />
        </svg>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-primary-foreground mb-4">
            Ready to Order?
          </h2>
          <p className="text-lg text-primary-foreground/80 max-w-2xl mx-auto font-arabic">
            هل أنت مستعد للطلب؟
          </p>
          <p className="text-lg text-primary-foreground/80 max-w-2xl mx-auto mt-2">
            Experience the authentic taste of Yemen from the comfort of your home 
            or dine with us for the full experience.
          </p>
        </motion.div>

        {/* Order Options Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {orderOptions.map((option, index) => (
            <motion.div
              key={option.title}
              initial={{ opacity: 0, y: 30 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <Card className="h-full bg-white/10 backdrop-blur-sm border-white/20 hover:bg-white/20 transition-colors">
                <CardContent className="p-6 text-center flex flex-col h-full">
                  <div className="w-14 h-14 mx-auto mb-4 bg-white/20 rounded-xl flex items-center justify-center">
                    <option.icon className="w-7 h-7 text-white" />
                  </div>
                  <h3 className="text-xl font-semibold text-white mb-2">{option.title}</h3>
                  <p className="text-white/70 text-sm mb-4 flex-grow">{option.description}</p>
                  <a href={option.href} target={option.href.startsWith('http') ? '_blank' : undefined} rel="noopener noreferrer">
                    <Button
                      variant={option.primary ? 'secondary' : 'outline'}
                      className={option.primary 
                        ? 'w-full bg-accent text-accent-foreground hover:bg-accent/90' 
                        : 'w-full border-white/30 text-white hover:bg-white/10'
                      }
                    >
                      {option.action}
                    </Button>
                  </a>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* Additional Info */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={isInView ? { opacity: 1 } : {}}
          transition={{ duration: 0.6, delay: 0.5 }}
          className="mt-12 text-center"
        >
          <p className="text-primary-foreground/60 text-sm">
            Free delivery available within Abu Dhabi. Minimum order AED 50.
          </p>
        </motion.div>
      </div>
    </section>
  )
}
