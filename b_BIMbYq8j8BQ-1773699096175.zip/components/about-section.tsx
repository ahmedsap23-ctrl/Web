'use client'

import { motion } from 'framer-motion'
import { useInView } from 'framer-motion'
import { useRef } from 'react'
import { Utensils, Users, Award, Clock } from 'lucide-react'
import Image from 'next/image'

const features = [
  {
    icon: Utensils,
    title: 'Authentic Recipes',
    description: 'Traditional Yemeni recipes passed down through generations'
  },
  {
    icon: Users,
    title: 'Family Atmosphere',
    description: 'Warm hospitality that makes every guest feel at home'
  },
  {
    icon: Award,
    title: 'Premium Quality',
    description: 'Fresh ingredients and finest spices for exceptional taste'
  },
  {
    icon: Clock,
    title: 'Traditional Cooking',
    description: 'Slow-cooked in underground tandoor for authentic flavors'
  }
]

export function AboutSection() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: '-100px' })

  return (
    <section id="about" className="py-20 md:py-32 bg-secondary">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div ref={ref} className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Image Side */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8 }}
            className="relative"
          >
            <div className="relative aspect-[4/3] rounded-2xl overflow-hidden shadow-2xl">
              <Image
                src="/images/restaurant-interior.jpg"
                alt="Happy Yemen Restaurant interior with traditional Yemeni decor"
                fill
                className="object-cover"
              />
            </div>
            {/* Decorative element */}
            <div className="absolute -bottom-6 -right-6 w-48 h-48 bg-accent/20 rounded-2xl -z-10" />
            <div className="absolute -top-6 -left-6 w-32 h-32 bg-primary/10 rounded-2xl -z-10" />
          </motion.div>

          {/* Content Side */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            <div className="flex items-center gap-2 mb-4">
              <div className="h-px w-12 bg-accent" />
              <span className="text-accent font-medium uppercase tracking-wider text-sm">
                Our Story
              </span>
            </div>
            
            <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-foreground mb-4">
              A Taste of Yemen in
              <span className="text-accent"> Abu Dhabi</span>
            </h2>
            
            <p className="text-lg text-muted-foreground mb-6 leading-relaxed">
              Welcome to Happy Yemen Restaurant, a beloved culinary destination bringing the rich 
              flavors of Yemeni cuisine to the heart of Abu Dhabi. For years, we have been serving 
              authentic dishes crafted with love, using traditional recipes and cooking methods 
              that have been perfected over generations.
            </p>
            
            <p className="text-muted-foreground mb-8 leading-relaxed">
              Our specialty lies in our signature Mandi and Madfoon, slow-cooked in traditional 
              underground tandoor ovens that infuse the meat with smoky, aromatic flavors. Every 
              dish is prepared with the freshest ingredients and a blend of spices that capture 
              the essence of Yemeni hospitality.
            </p>

            {/* Feature Grid */}
            <div className="grid sm:grid-cols-2 gap-6">
              {features.map((feature, index) => (
                <motion.div
                  key={feature.title}
                  initial={{ opacity: 0, y: 20 }}
                  animate={isInView ? { opacity: 1, y: 0 } : {}}
                  transition={{ duration: 0.5, delay: 0.4 + index * 0.1 }}
                  className="flex gap-4"
                >
                  <div className="flex-shrink-0 w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                    <feature.icon className="w-6 h-6 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-foreground mb-1">{feature.title}</h3>
                    <p className="text-sm text-muted-foreground">{feature.description}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}
