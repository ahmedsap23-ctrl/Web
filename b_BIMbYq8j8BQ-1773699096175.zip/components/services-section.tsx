'use client'

import { useRef } from 'react'
import { motion, useInView } from 'framer-motion'
import { UtensilsCrossed, Car, Truck, ShoppingBag } from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'

const services = [
  {
    icon: UtensilsCrossed,
    title: 'Dine-In',
    titleArabic: 'تناول الطعام',
    description: 'Enjoy your meal in our warm and welcoming restaurant atmosphere with traditional Yemeni hospitality.',
    available: true
  },
  {
    icon: Car,
    title: 'Drive-Through',
    titleArabic: 'خدمة السيارة',
    description: 'Quick and convenient service without leaving your car. Perfect for busy schedules.',
    available: true
  },
  {
    icon: Truck,
    title: 'Delivery',
    titleArabic: 'توصيل',
    description: 'No-contact delivery bringing authentic Yemeni flavors right to your doorstep.',
    available: true
  },
  {
    icon: ShoppingBag,
    title: 'Takeaway',
    titleArabic: 'طلب خارجي',
    description: 'Order ahead and pick up your freshly prepared meal at your convenience.',
    available: true
  }
]

function ServiceCard({ service, index }: { service: typeof services[0]; index: number }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
    >
      <Card className="h-full group hover:shadow-xl transition-all duration-300 border-border/50 overflow-hidden">
        <CardContent className="p-6 text-center">
          <motion.div
            whileHover={{ scale: 1.1, rotate: 5 }}
            className="w-16 h-16 mx-auto mb-4 bg-primary/10 rounded-2xl flex items-center justify-center group-hover:bg-primary/20 transition-colors"
          >
            <service.icon className="w-8 h-8 text-primary" />
          </motion.div>
          <h3 className="text-xl font-semibold text-foreground mb-1">{service.title}</h3>
          <p className="text-sm text-accent font-arabic mb-3">{service.titleArabic}</p>
          <p className="text-muted-foreground text-sm leading-relaxed">
            {service.description}
          </p>
          {service.available && (
            <div className="mt-4 inline-flex items-center gap-2 text-sm text-green-600 bg-green-50 px-3 py-1 rounded-full">
              <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
              Available Now
            </div>
          )}
        </CardContent>
      </Card>
    </motion.div>
  )
}

export function ServicesSection() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: '-100px' })

  return (
    <section id="services" className="py-20 md:py-32 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <div className="flex items-center justify-center gap-2 mb-4">
            <div className="h-px w-12 bg-accent" />
            <span className="text-accent font-medium uppercase tracking-wider text-sm">
              Our Services
            </span>
            <div className="h-px w-12 bg-accent" />
          </div>
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-foreground mb-4">
            How Would You Like to <span className="text-accent">Enjoy</span>?
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Multiple ways to experience our authentic Yemeni cuisine, 
            designed for your convenience.
          </p>
        </motion.div>

        {/* Services Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {services.map((service, index) => (
            <ServiceCard key={service.title} service={service} index={index} />
          ))}
        </div>
      </div>
    </section>
  )
}
