export interface MenuItem {
  id: string
  name: string
  nameArabic: string
  description: string
  price: number
  image: string
  category: string
  popular?: boolean
}

export interface MenuCategory {
  id: string
  name: string
  nameArabic: string
  description: string
}

export const menuCategories: MenuCategory[] = [
  {
    id: 'mandi',
    name: 'Mandi',
    nameArabic: 'مندي',
    description: 'Traditional Yemeni rice dishes cooked in underground tandoor'
  },
  {
    id: 'madfoon',
    name: 'Madfoon',
    nameArabic: 'مدفون',
    description: 'Slow-cooked meat buried under spiced rice'
  },
  {
    id: 'fahsa',
    name: 'Fahsa',
    nameArabic: 'فحسة',
    description: 'Traditional lamb stew served sizzling hot'
  },
  {
    id: 'grilled',
    name: 'Grilled Meats',
    nameArabic: 'مشويات',
    description: 'Fresh grilled meats and kebabs'
  },
  {
    id: 'sides',
    name: 'Bread & Sides',
    nameArabic: 'خبز ومقبلات',
    description: 'Traditional breads and accompaniments'
  },
  {
    id: 'drinks',
    name: 'Drinks',
    nameArabic: 'مشروبات',
    description: 'Refreshing beverages and traditional drinks'
  }
]

export const menuItems: MenuItem[] = [
  // Mandi
  {
    id: 'mandi-chicken',
    name: 'Chicken Mandi',
    nameArabic: 'مندي دجاج',
    description: 'Tender chicken slow-cooked with aromatic spices and basmati rice in traditional tandoor',
    price: 55,
    image: '/images/mandi-chicken.jpg',
    category: 'mandi',
    popular: true
  },
  {
    id: 'mandi-lamb',
    name: 'Lamb Mandi',
    nameArabic: 'مندي لحم',
    description: 'Succulent lamb cooked to perfection with fragrant rice and Yemeni spice blend',
    price: 85,
    image: '/images/mandi-lamb.jpg',
    category: 'mandi',
    popular: true
  },
  {
    id: 'mandi-mixed',
    name: 'Mixed Mandi',
    nameArabic: 'مندي مشكل',
    description: 'A combination of tender chicken and lamb served on aromatic rice',
    price: 95,
    image: '/images/mandi-mixed.jpg',
    category: 'mandi'
  },
  // Madfoon
  {
    id: 'madfoon-chicken',
    name: 'Chicken Madfoon',
    nameArabic: 'مدفون دجاج',
    description: 'Whole chicken buried and slow-cooked under spiced rice until fall-off-the-bone tender',
    price: 60,
    image: '/images/madfoon-chicken.jpg',
    category: 'madfoon',
    popular: true
  },
  {
    id: 'madfoon-lamb',
    name: 'Lamb Madfoon',
    nameArabic: 'مدفون لحم',
    description: 'Premium lamb slowly cooked underground with aromatic spices and rice',
    price: 90,
    image: '/images/madfoon-lamb.jpg',
    category: 'madfoon'
  },
  // Fahsa
  {
    id: 'fahsa-lamb',
    name: 'Lamb Fahsa',
    nameArabic: 'فحسة لحم',
    description: 'Traditional sizzling lamb stew with hulba (fenugreek foam) and spices',
    price: 65,
    image: '/images/fahsa-lamb.jpg',
    category: 'fahsa',
    popular: true
  },
  {
    id: 'fahsa-chicken',
    name: 'Chicken Fahsa',
    nameArabic: 'فحسة دجاج',
    description: 'Tender chicken in traditional fahsa sauce with fenugreek',
    price: 50,
    image: '/images/fahsa-chicken.jpg',
    category: 'fahsa'
  },
  // Grilled Meats
  {
    id: 'mixed-grill',
    name: 'Mixed Grill Platter',
    nameArabic: 'مشاوي مشكلة',
    description: 'Assorted grilled meats including kebab, tikka, and lamb chops',
    price: 120,
    image: '/images/mixed-grill.jpg',
    category: 'grilled',
    popular: true
  },
  {
    id: 'lamb-kebab',
    name: 'Lamb Kebab',
    nameArabic: 'كباب لحم',
    description: 'Minced lamb seasoned with Middle Eastern spices, grilled to perfection',
    price: 45,
    image: '/images/lamb-kebab.jpg',
    category: 'grilled'
  },
  {
    id: 'chicken-tikka',
    name: 'Chicken Tikka',
    nameArabic: 'تكا دجاج',
    description: 'Marinated chicken pieces grilled on skewers',
    price: 40,
    image: '/images/chicken-tikka.jpg',
    category: 'grilled'
  },
  // Bread & Sides
  {
    id: 'mulawah',
    name: 'Mulawah Bread',
    nameArabic: 'ملوح',
    description: 'Traditional Yemeni layered flatbread, crispy and buttery',
    price: 15,
    image: '/images/mulawah.jpg',
    category: 'sides'
  },
  {
    id: 'fatoot',
    name: 'Fatoot',
    nameArabic: 'فتوت',
    description: 'Crispy bread pieces mixed with honey and ghee',
    price: 20,
    image: '/images/fatoot.jpg',
    category: 'sides'
  },
  {
    id: 'hummus',
    name: 'Hummus',
    nameArabic: 'حمص',
    description: 'Creamy chickpea dip with olive oil and spices',
    price: 18,
    image: '/images/hummus.jpg',
    category: 'sides'
  },
  {
    id: 'salad',
    name: 'Arabic Salad',
    nameArabic: 'سلطة عربية',
    description: 'Fresh vegetables with lemon dressing',
    price: 15,
    image: '/images/salad.jpg',
    category: 'sides'
  },
  // Drinks
  {
    id: 'yemeni-tea',
    name: 'Yemeni Tea',
    nameArabic: 'شاي يمني',
    description: 'Traditional spiced tea with cardamom and cloves',
    price: 10,
    image: '/images/yemeni-tea.jpg',
    category: 'drinks'
  },
  {
    id: 'fresh-juice',
    name: 'Fresh Juice',
    nameArabic: 'عصير طازج',
    description: 'Choice of mango, orange, or mixed fruit',
    price: 15,
    image: '/images/fresh-juice.jpg',
    category: 'drinks'
  },
  {
    id: 'laban',
    name: 'Laban',
    nameArabic: 'لبن',
    description: 'Traditional buttermilk drink, refreshing and cooling',
    price: 12,
    image: '/images/laban.jpg',
    category: 'drinks'
  }
]

export const reviews = [
  {
    id: 1,
    name: 'Ahmed Al-Mansouri',
    rating: 5,
    comment: 'Best Mandi in Abu Dhabi! The lamb is so tender and the rice is perfectly spiced. A true taste of Yemen.',
    date: '2 weeks ago'
  },
  {
    id: 2,
    name: 'Sarah Johnson',
    rating: 5,
    comment: 'Amazing authentic Yemeni food! The Fahsa was incredible - served sizzling hot with fresh bread. Highly recommend!',
    date: '1 month ago'
  },
  {
    id: 3,
    name: 'Mohammed Hassan',
    rating: 4,
    comment: 'Great food and generous portions. The Madfoon chicken was fall-off-the-bone tender. Will definitely come back.',
    date: '3 weeks ago'
  },
  {
    id: 4,
    name: 'Fatima Al-Rashid',
    rating: 5,
    comment: 'Finally found authentic Yemeni cuisine in UAE! The spices are perfect and the meat quality is excellent.',
    date: '1 week ago'
  },
  {
    id: 5,
    name: 'David Chen',
    rating: 4,
    comment: 'First time trying Yemeni food and I am impressed! The mixed grill was fantastic and the service was excellent.',
    date: '2 months ago'
  }
]
